package com.quinnox.assetmanagement2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssetManagement2Application {

	public static void main(String[] args) {
		SpringApplication.run(AssetManagement2Application.class, args);
	}

}
